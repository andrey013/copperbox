{-# OPTIONS -Wall #-}
--------------------------------------------------------------------------------
-- |
-- Module      :  Mullein.LilyPondNoteClass
-- Copyright   :  (c) Stephen Tetley 2009
-- License     :  BSD3
--
-- Maintainer  :  Stephen Tetley <stephen.tetley@gmail.com>
-- Stability   :  highly unstable
-- Portability :  GHC
--
-- Operations a /Note/ must support to be renderable with LilyPond.
--
--------------------------------------------------------------------------------

module Mullein.LilyPondNoteClass ( 
  LyNote(..),
  ExchangePitch(..),

  ) where

import Mullein.Duration
import Mullein.Pitch

import Text.PrettyPrint.Leijen


class LyNote e where
  rewritePitch :: ExchangePitch m => e -> m e
  rewritePitches :: ExchangePitch m => [e] -> m [e]

  lyNote  :: e -> Maybe Duration -> Doc   -- for notes
  lyPitch :: e -> Doc               -- for pitches within chords, graces notes,

class Monad m => ExchangePitch m where
  exchangePitch :: Pitch -> m Pitch

